(function(){
  const cards = Array.from(document.querySelectorAll('.la-photo-card'));
  if(!cards.length) return;

  let activeCard = null;

  function clearActive(){
    if(activeCard){
      activeCard.classList.remove('la-active');
      activeCard = null;
    }
  }

  cards.forEach(card=>{
    card.addEventListener('touchstart', function(ev){
      if(activeCard === card){ return; }
      ev.preventDefault();
      clearActive();
      card.classList.add('la-active');
      activeCard = card;
    });
  });

  document.addEventListener('touchstart', function(ev){
    if(!ev.target.closest || ev.target.closest('.la-photo-card')) return;
    clearActive();
  });

  // Atualização dinâmica opcional
  window.laUpdateInfo = function({hours, address}){
    if(hours) document.getElementById('la-hours').querySelector('.la-value').textContent = hours;
    if(address) document.getElementById('la-address').querySelector('.la-value').textContent = address;
  }
})();